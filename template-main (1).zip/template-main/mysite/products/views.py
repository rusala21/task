from django.shortcuts import render

def index(request):
    return render(request, 'products/index.html')

def products_view(request):
    return render(request, 'products/products.html')
def checkout_view(request):
    return render(request, 'products/order-create.html')  # checkout page
