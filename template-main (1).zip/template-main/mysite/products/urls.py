from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),                  # Homepage
    path('products/', views.products_view, name='products'),
    path('checkout/', views.checkout_view, name='orders'),   # Checkout page
]
